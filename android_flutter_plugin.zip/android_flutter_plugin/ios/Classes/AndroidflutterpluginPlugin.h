#import <Flutter/Flutter.h>

@interface AndroidflutterpluginPlugin : NSObject<FlutterPlugin>
@end
