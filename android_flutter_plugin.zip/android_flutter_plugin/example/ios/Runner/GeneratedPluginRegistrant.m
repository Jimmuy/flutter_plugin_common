//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<androidflutterplugin/AndroidflutterpluginPlugin.h>)
#import <androidflutterplugin/AndroidflutterpluginPlugin.h>
#else
@import androidflutterplugin;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [AndroidflutterpluginPlugin registerWithRegistrar:[registry registrarForPlugin:@"AndroidflutterpluginPlugin"]];
}

@end
